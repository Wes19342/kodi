import sys
import urllib.parse
import xbmcplugin
import xbmcgui

handle = int(sys.argv[1])
base_url = sys.argv[0]
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

def list_items():
    url = f"{base_url}?action=play&video_url=https://www.sample-videos.com/video123/mp4/720/big_buck_bunny_720p_20mb.mp4"
    li = xbmcgui.ListItem(label="Sample Video")
    li.setInfo('video', {'title': 'Big Buck Bunny'})
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

def play_video(video_url):
    play_item = xbmcgui.ListItem(path=video_url)
    xbmcplugin.setResolvedUrl(handle, True, listitem=play_item)

if __name__ == '__main__':
    action = params.get('action')
    if action == 'play':
        play_video(params['video_url'])
    else:
        list_items()
